/*
 * variaveisPseudoMain.c
 *
 *  Created on: Feb 3, 2024
 *      Author: caiof
 */


